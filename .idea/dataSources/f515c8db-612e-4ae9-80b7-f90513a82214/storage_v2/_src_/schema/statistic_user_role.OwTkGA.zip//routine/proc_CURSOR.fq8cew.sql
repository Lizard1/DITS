create procedure proc_CURSOR(OUT param1 int)
BEGIN 
	    DECLARE a, b, c INT; 
	    DECLARE curs1 CURSOR FOR SELECT correct FROM statistic; 
	    DECLARE CONTINUE HANDLER FOR NOT FOUND SET b = 1; 
	    OPEN curs1; 
	    SET b = 0; 
	    SET c = 0; 
	    WHILE b = 0 DO 
	        FETCH curs1 INTO a; 
	        IF a = 1 THEN 
	            SET c = c + a; 
	    END IF; 
	    END WHILE; 
	    CLOSE curs1; 
	    SET param1 = c; 
	END;

